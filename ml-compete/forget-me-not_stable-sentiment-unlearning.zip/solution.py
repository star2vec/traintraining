# problema https://platform.olimpiada-ai.ro/ro/problems/288

from __future__ import annotations

import copy
import json
from pathlib import Path

from common import load_state, save_state, active_feature_indices


def unlearn(proxy_train_csv, pretrained_model_dir, forget_spec_json, output_dir, seed):
    """Minimal valid submission. It intentionally performs no real unlearning."""
    state = copy.deepcopy(load_state(pretrained_model_dir))

    with open(forget_spec_json, "r", encoding="utf-8") as fin:
        spec = json.load(fin)
    g = spec["phrase_grammar"]

    phrases = []
    for head in g["head"]:
        for con in g["connector"]:
            for a in g["positive_a"]:
                for b in g["positive_b"]:
                    phrases.append(head + " " + con + " " + a + " " + b)
            for a in g["negative_a"]:
                for b in g["negative_b"]:
                    phrases.append(head + " " + con + " " + a + " " + b)
    
    idxs = active_feature_indices(phrases)

    for i in idxs:
        state["weights"][i] = 0.0
        state["frozen_mask"][i] = True

    return save_state(output_dir, state, method="zero and freeze watermark buckets")