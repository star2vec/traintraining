from __future__ import annotations

import hashlib
import json
import pickle
from pathlib import Path

import numpy as np
from scipy.sparse import hstack
from sklearn.feature_extraction.text import HashingVectorizer

WORD_FEATURES = 4096
CHAR_FEATURES = 4096
N_FEATURES = WORD_FEATURES + CHAR_FEATURES
MAX_FROZEN_FRACTION = 0.15
FEATURE_CONFIG = {'word_features': 4096, 'char_features': 4096, 'word_ngram_range': [1, 2], 'char_ngram_range': [3, 5], 'alternate_sign': False, 'normalization': 'l2-per-block', 'lowercase': True}
FEATURE_SIGNATURE = '3dac58243dadf2d90e8fefe21aa425e9c61a0607a4416e86cf8280b96c7423cb'

_WORD_VECTORIZER = HashingVectorizer(
    n_features=WORD_FEATURES,
    alternate_sign=False,
    norm="l2",
    ngram_range=(1, 2),
    lowercase=True,
    token_pattern=r"(?u)\b\w+\b",
)
_CHAR_VECTORIZER = HashingVectorizer(
    n_features=CHAR_FEATURES,
    alternate_sign=False,
    norm="l2",
    analyzer="char_wb",
    ngram_range=(3, 5),
    lowercase=True,
)


def featurize(texts):
    texts = [str(x) for x in texts]
    return hstack([
        _WORD_VECTORIZER.transform(texts),
        _CHAR_VECTORIZER.transform(texts),
    ], format="csr")


def sigmoid(values):
    values = np.asarray(values, dtype=np.float64)
    return 1.0 / (1.0 + np.exp(-np.clip(values, -40.0, 40.0)))


def predict_proba(state, texts):
    X = featurize(texts)
    return sigmoid(X.dot(np.asarray(state["weights"], dtype=np.float64)) + float(state["bias"]))


def load_state(model_dir):
    model_dir = Path(model_dir)
    with (model_dir / "state.pkl").open("rb") as fin:
        state = pickle.load(fin)
    return state


def save_state(output_dir, state, method):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "state.pkl").open("wb") as fout:
        pickle.dump(state, fout, protocol=4)
    state_sha = hashlib.sha256((output_dir / "state.pkl").read_bytes()).hexdigest()
    meta = {
        "format_version": 1,
        "method": str(method),
        "feature_signature": FEATURE_SIGNATURE,
        "state_sha256": state_sha,
    }
    (output_dir / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    manifest = {
        "format_version": 1,
        "model_files": ["state.pkl", "meta.json"],
    }
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return str(manifest_path)


def active_feature_indices(strings):
    X = featurize(strings)
    return np.unique(X.indices)
